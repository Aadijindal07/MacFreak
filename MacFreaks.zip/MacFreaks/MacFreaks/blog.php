<?php include_once 'header.php';?>
    <!-- header end -->
    <main>
        <!-- breadcrumb Start-->
        <div class="page-notification page-notification2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                <li class="breadcrumb-item"><a href="#">Blog</a></li> 
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb End-->
        <!-- Hero Area End-->
        <!--? Blog Area Start-->
        <section class="blog_area section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 mb-5 mb-lg-0">
                        <div class="blog_left_sidebar">
                            <article class="blog_item">
                                <div class="blog_details">
                                <img class="card-img rounded-0" src="assets/img/blog/single_blog_4.jpg" alt="">
                                    <a class="d-inline-block" href="blog_details.html">
                                        <h2 class="blog-head" style="color: #2d2d2d;">Top 10 Macbooks</h2>
                                    </a>
                                    <ul class="blog-info-link">
                                        <li>Read More</li>
                                    </ul>
                                </div>
                            </article>
                            
                            <article class="blog_item">
                                <div class="blog_details">
                                <img class="card-img rounded-0" src="assets/img/blog/single_blog_5.jpg" alt="">
                                    <a class="d-inline-block" href="blog_details.html">
                                        <h2 class="blog-head" style="color: #2d2d2d;">Top 10 Imac</h2>
                                    </a>
                                    <ul class="blog-info-link">
                                        <li>Read More</li>
                                    </ul>
                                </div>
                            </article>
                          
                            
                            <nav class="blog-pagination justify-content-center d-flex">
                                <ul class="pagination">
                                    <li class="page-item">
                                        <a href="#" class="page-link" aria-label="Previous">
                                            <i class="ti-angle-left"></i>
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a href="#" class="page-link">1</a>
                                    </li>
                                    <li class="page-item active">
                                        <a href="#" class="page-link">2</a>
                                    </li>
                                    <li class="page-item">
                                        <a href="#" class="page-link" aria-label="Next">
                                            <i class="ti-angle-right"></i>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="blog_right_sidebar">
                            
                            
                           
                            <aside class="single_sidebar_widget instagram_feeds">
                                <h4 class="widget_title" style="color: #2d2d2d;">Instagram Feeds</h4>
                                <ul class="instagram_row flex-wrap">
                                    <li>
                                        <a href="https://www.instagram.com/macfreaks_mumbai/">
                                            <img class="img-fluid" src="assets/img/post/1.png" alt="">
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/macfreaks_mumbai/">
                                            <img class="img-fluid" src="assets/img/post/2.png" alt="">
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/macfreaks_mumbai/">
                                            <img class="img-fluid" src="assets/img/post/3.png" alt="">
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/macfreaks_mumbai/">
                                            <img class="img-fluid" src="assets/img/post/4.png" alt="">
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/macfreaks_mumbai/">
                                            <img class="img-fluid" src="assets/img/post/5.png" alt="">
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/macfreaks_mumbai/">
                                            <img class="img-fluid" src="assets/img/post/6.png" alt="">
                                        </a>
                                    </li>
                                </ul>
                            </aside>
                            <aside class="single_sidebar_widget newsletter_widget">
                                <h4 class="widget_title" style="color: #2d2d2d;">Newsletter</h4>
                                <form action="#">
                                    <div class="form-group">
                                        <input type="email" class="form-control" onfocus="this.placeholder = ''"
                                        onblur="this.placeholder = 'Enter email'" placeholder='Enter email' required>
                                    </div>
                                    <button class="button rounded-0 primary-bg text-white w-100 btn_1 boxed-btn"
                                    type="submit">Subscribe</button>
                                </form>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Blog Area End -->
    </main>
                            <?php include_once 'footer.php';?>
                           